<!doctype html>
<html lang ="en">
	<head>
		<title>Home</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="../css/pageStyle.css" rel="stylesheet" type="text/css"/>
		<?php include 'headerFooter.php'?>;
	</head>
	
		</div>
	
	</body>
</html>